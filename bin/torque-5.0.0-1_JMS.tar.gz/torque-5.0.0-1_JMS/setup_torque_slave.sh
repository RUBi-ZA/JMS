#!/bin/bash

set -e

IP=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'`

#Compile and install Torque
./configure --enable-maxdefault --disable-server
make
make install

./libtool --finish /usr/local/lib

#Install latest libtorque library (possibly Ubuntu/Debian specific?)
cp src/lib/Libpbs/.libs/libtorque.so.2.0.0 /usr/local/lib/
rm /usr/lib/libtorque.so.2
ln -s /usr/local/lib/libtorque.so.2 /usr/lib

HEAD_NODE=${1}
HEAD_IP=${2}
echo $HEAD_NODE  > /var/spool/torque/server_name
echo "$HEAD_IP\t$HEAD_NODE torqueserver" >> /etc/hosts

#Add start-up daemon services (would need to be changed for other Linux distributions)
cp contrib/init.d/debian.trqauthd /etc/init.d/trqauthd
cp contrib/init.d/debian.pbs_mom /etc/init.d/pbs_mom

update-rc.d trqauthd defaults
update-rc.d pbs_mom defaults

service pbs_trqauthd start
service pbs_mom start
